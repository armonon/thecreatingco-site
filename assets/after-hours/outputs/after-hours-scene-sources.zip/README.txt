After Hours — ScenePilot source bundle

Three original five-second source clips, the actual StemDeck mix, and the exported ScenePilot cut map. These MP4 files are INPUT clips, not a rendered ScenePilot trailer. Import the source media and cut map in ScenePilot; relinking may be required.

01: original AI-generated artwork, animated with a gentle pan/zoom.
02: original AI-generated jacket front reference, animated with a gentle pan/zoom.
03: actual PNG rendered from the Form clasp study, animated with a gentle pan/zoom.
WAV: actual 18-second StemDeck browser mix of four original composed parts.
Cut JSON: actual ScenePilot Browser Lite export, 18 seconds, 104 BPM, 10 master cuts and five overlay placements.

Project save and reload were verified in the browser. Final MP4 export canceled before writing. No finished ScenePilot render is included.
